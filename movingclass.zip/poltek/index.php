<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0;url=pages/index.html">
<title>Polkesma</title>
<script language="javascript">
    window.location.href = "pages/"
</script>
</head>
</html>
